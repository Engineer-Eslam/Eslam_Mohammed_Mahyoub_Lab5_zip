﻿namespace إسلام_محمد_مهيوب_المليكي_lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button_Sum = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.red_background = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Black_background = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.Yellow_background = new System.Windows.Forms.RadioButton();
            this.Green_background = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Color_text_Green = new System.Windows.Forms.RadioButton();
            this.Color_text_Black = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.Color_text_Yellow = new System.Windows.Forms.RadioButton();
            this.Color_text_Red = new System.Windows.Forms.RadioButton();
            this.button_Applying = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.Enabled = new System.Windows.Forms.Button();
            this.Visible = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBox5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.button_Sum);
            this.panel1.Controls.Add(this.checkBox4);
            this.panel1.Controls.Add(this.checkBox3);
            this.panel1.Controls.Add(this.checkBox2);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Location = new System.Drawing.Point(267, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(148, 280);
            this.panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(7, 239);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(134, 30);
            this.textBox1.TabIndex = 10;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button_Sum
            // 
            this.button_Sum.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Sum.Location = new System.Drawing.Point(16, 197);
            this.button_Sum.Name = "button_Sum";
            this.button_Sum.Size = new System.Drawing.Size(112, 36);
            this.button_Sum.TabIndex = 9;
            this.button_Sum.Text = "حساب";
            this.button_Sum.UseVisualStyleBackColor = true;
            this.button_Sum.Click += new System.EventHandler(this.button_Sum_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(47, 131);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(59, 27);
            this.checkBox4.TabIndex = 4;
            this.checkBox4.Text = "400";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(47, 98);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(59, 27);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "300";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(47, 65);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(59, 27);
            this.checkBox2.TabIndex = 2;
            this.checkBox2.Text = "200";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(47, 32);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(59, 27);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "100";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // red_background
            // 
            this.red_background.AutoSize = true;
            this.red_background.Location = new System.Drawing.Point(23, 54);
            this.red_background.Name = "red_background";
            this.red_background.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.red_background.Size = new System.Drawing.Size(66, 27);
            this.red_background.TabIndex = 5;
            this.red_background.TabStop = true;
            this.red_background.Text = "أحمر";
            this.red_background.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Black_background);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.Yellow_background);
            this.panel2.Controls.Add(this.Green_background);
            this.panel2.Controls.Add(this.red_background);
            this.panel2.Location = new System.Drawing.Point(12, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(116, 280);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(9, 228);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "CrazyIT";
            // 
            // Black_background
            // 
            this.Black_background.AutoSize = true;
            this.Black_background.Location = new System.Drawing.Point(20, 186);
            this.Black_background.Name = "Black_background";
            this.Black_background.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Black_background.Size = new System.Drawing.Size(69, 27);
            this.Black_background.TabIndex = 11;
            this.Black_background.TabStop = true;
            this.Black_background.Text = "أسود";
            this.Black_background.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 8;
            this.label2.Text = "لون الخلفيه";
            // 
            // Yellow_background
            // 
            this.Yellow_background.AutoSize = true;
            this.Yellow_background.Location = new System.Drawing.Point(24, 97);
            this.Yellow_background.Name = "Yellow_background";
            this.Yellow_background.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Yellow_background.Size = new System.Drawing.Size(65, 27);
            this.Yellow_background.TabIndex = 6;
            this.Yellow_background.TabStop = true;
            this.Yellow_background.Text = "أصفر";
            this.Yellow_background.UseVisualStyleBackColor = true;
            // 
            // Green_background
            // 
            this.Green_background.AutoSize = true;
            this.Green_background.Location = new System.Drawing.Point(20, 141);
            this.Green_background.Name = "Green_background";
            this.Green_background.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Green_background.Size = new System.Drawing.Size(69, 27);
            this.Green_background.TabIndex = 10;
            this.Green_background.TabStop = true;
            this.Green_background.Text = "أخضر";
            this.Green_background.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button_Applying);
            this.panel3.Controls.Add(this.Color_text_Green);
            this.panel3.Controls.Add(this.Color_text_Black);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.Color_text_Yellow);
            this.panel3.Controls.Add(this.Color_text_Red);
            this.panel3.Location = new System.Drawing.Point(143, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(112, 280);
            this.panel3.TabIndex = 7;
            // 
            // Color_text_Green
            // 
            this.Color_text_Green.AutoSize = true;
            this.Color_text_Green.Location = new System.Drawing.Point(19, 141);
            this.Color_text_Green.Name = "Color_text_Green";
            this.Color_text_Green.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Color_text_Green.Size = new System.Drawing.Size(69, 27);
            this.Color_text_Green.TabIndex = 12;
            this.Color_text_Green.TabStop = true;
            this.Color_text_Green.Text = "أخضر";
            this.Color_text_Green.UseVisualStyleBackColor = true;
            // 
            // Color_text_Black
            // 
            this.Color_text_Black.AutoSize = true;
            this.Color_text_Black.Location = new System.Drawing.Point(19, 186);
            this.Color_text_Black.Name = "Color_text_Black";
            this.Color_text_Black.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Color_text_Black.Size = new System.Drawing.Size(69, 27);
            this.Color_text_Black.TabIndex = 13;
            this.Color_text_Black.TabStop = true;
            this.Color_text_Black.Text = "أسود";
            this.Color_text_Black.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 23);
            this.label3.TabIndex = 7;
            this.label3.Text = "لون النص";
            // 
            // Color_text_Yellow
            // 
            this.Color_text_Yellow.AutoSize = true;
            this.Color_text_Yellow.Location = new System.Drawing.Point(23, 97);
            this.Color_text_Yellow.Name = "Color_text_Yellow";
            this.Color_text_Yellow.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Color_text_Yellow.Size = new System.Drawing.Size(65, 27);
            this.Color_text_Yellow.TabIndex = 6;
            this.Color_text_Yellow.TabStop = true;
            this.Color_text_Yellow.Text = "أصفر";
            this.Color_text_Yellow.UseVisualStyleBackColor = true;
            // 
            // Color_text_Red
            // 
            this.Color_text_Red.AutoSize = true;
            this.Color_text_Red.Location = new System.Drawing.Point(22, 54);
            this.Color_text_Red.Name = "Color_text_Red";
            this.Color_text_Red.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Color_text_Red.Size = new System.Drawing.Size(66, 27);
            this.Color_text_Red.TabIndex = 5;
            this.Color_text_Red.TabStop = true;
            this.Color_text_Red.Text = "أحمر";
            this.Color_text_Red.UseVisualStyleBackColor = true;
            // 
            // button_Applying
            // 
            this.button_Applying.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_Applying.Location = new System.Drawing.Point(9, 223);
            this.button_Applying.Name = "button_Applying";
            this.button_Applying.Size = new System.Drawing.Size(88, 36);
            this.button_Applying.TabIndex = 8;
            this.button_Applying.Text = "تطبيق";
            this.button_Applying.UseVisualStyleBackColor = true;
            this.button_Applying.Click += new System.EventHandler(this.button_Applying_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 23);
            this.label4.TabIndex = 14;
            this.label4.Text = "اختر ثم احسب";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(47, 164);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(59, 27);
            this.checkBox5.TabIndex = 15;
            this.checkBox5.Text = "500";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // Enabled
            // 
            this.Enabled.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Enabled.Location = new System.Drawing.Point(66, 311);
            this.Enabled.Name = "Enabled";
            this.Enabled.Size = new System.Drawing.Size(112, 36);
            this.Enabled.TabIndex = 16;
            this.Enabled.Text = "Enabled";
            this.Enabled.UseVisualStyleBackColor = true;
            this.Enabled.Click += new System.EventHandler(this.Enabled_Click);
            // 
            // Visible
            // 
            this.Visible.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Visible.Location = new System.Drawing.Point(261, 311);
            this.Visible.Name = "Visible";
            this.Visible.Size = new System.Drawing.Size(112, 36);
            this.Visible.TabIndex = 19;
            this.Visible.Text = "Visible";
            this.Visible.UseVisualStyleBackColor = true;
            this.Visible.Click += new System.EventHandler(this.Visible_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(437, 385);
            this.Controls.Add(this.Visible);
            this.Controls.Add(this.Enabled);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.RadioButton red_background;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton Yellow_background;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RadioButton Color_text_Yellow;
        private System.Windows.Forms.RadioButton Color_text_Red;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_Sum;
        private System.Windows.Forms.Button button_Applying;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton Black_background;
        private System.Windows.Forms.RadioButton Green_background;
        private System.Windows.Forms.RadioButton Color_text_Black;
        private System.Windows.Forms.RadioButton Color_text_Green;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Button Enabled;
        private System.Windows.Forms.Button Visible;
    }
}

